package bol1;

public class Ejercicio_2 {
	public static void main(String[] args) {
		float y = 5.0f;
		float x = 6.0f;
		float division = y % x;
		System.out.println(division);
	}

}
