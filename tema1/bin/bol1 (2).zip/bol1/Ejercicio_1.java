package bol1;

public class Ejercicio_1 {

	public static void main(String[] args) {
		int y = 4;
		int z = 3;
		int res = y*z;
		
		
		System.out.println(res);	

	}

}
